# urtypes

Python implementation of the [Blockchain Commons UR Types specification](https://github.com/BlockchainCommons/Research/blob/master/papers/bcr-2020-006-urtypes.md)