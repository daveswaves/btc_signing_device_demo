# Mnemonic Generator

### Overview

The ***Mnemonic Generator*** is a Python program that creates secure, human-readable mnemonic phrases based on cryptographic entropy. These phrases can be used for applications like cryptocurrency wallets or secure seed generation, following the BIP-39 standard.

---

### Features

* Generate 12-word or 24-word mnemonic phrases based on 128-bit or 256-bit entropy, respectively.
* Provides detailed breakdowns of the binary, decimal, and word associations for each segment.
* Implements cryptographic checksum calculations to ensure phrase integrity.
* Simulates realistic keyboard typing for enhanced user interaction.

---

### How It Works

1. Entropy Selection: Choose between 128-bit (12 words) or 256-bit (24 words) entropy.
2. Entropy and Checksum Generation:
* The program generates random entropy bits.
* A cryptographic checksum (based on SHA-256) is appended to the entropy.
3. Binary Segmentation: The combined binary string is split into 11-bit segments.
4. Word Mapping: Each 11-bit segment is mapped to a word from the BIP-39 wordlist.
5. Display:
* A detailed table shows the binary, decimal, and word mapping for each segment.
* The mnemonic phrase is presented as a space-separated string.

---

### Prerequisites

* Python 3.7 or later
* [embit library](https://embit.rocks/#/api/README)

---

### Usage

1. Run the program:
```bash
python3 mnemonic_generator.py
```
2. Enter your choice of entropy:
* `12` or `128` for a 12-word mnemonic (128-bit entropy).
* `24` or `256` for a 24-word mnemonic (256-bit entropy).

3. The program will generate and display:
* The binary entropy and checksum.
* A detailed breakdown of binary segments and their corresponding words.
* The final mnemonic phrase.

---

## Example Output

### User Input:
```javascript
Choose 12 word mnemonic (128-bit entropy) or 24 word mnemonic (256-bit entropy).
Enter 12, 24, 128 or 256: 12
```

### Output:
```javascript
Generated 128-bit binary private key: 100111...0101
Generated checksum (4 bits): 1100

Append checksum and split into 11-bit segments:
+---------------+------------------+----------+
| 11-bit binary | 4-digit decimal  | word     |
+---------------+------------------+----------+
| 10011101110   | 1262             | oven     |
| 10011101110   | 0906             | image    |
| 01111111000   | 1016             | lecture  |
| ...           | ...              | ...      |
| 01101011100   | 0860             | high     |
+---------------+------------------+----------+

Mnemonic (12 word seed phrase): oven image lecture ... high
```

---

### Notes

* The program follows the BIP-39 mnemonic generation standard for entropy, checksum, and word selection.
* Ensure the generated mnemonic is securely stored and never shared with unauthorized parties.
